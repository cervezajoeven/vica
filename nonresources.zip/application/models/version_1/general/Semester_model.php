<?php
class Semester_model extends BEN_Model {

	public $table = "semester";

	

}
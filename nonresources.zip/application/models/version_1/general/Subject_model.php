<?php
class Subject_model extends BEN_Model {

	public $table = "subject";
	
}

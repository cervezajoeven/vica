<?php
class Schedule_model extends BEN_Model {

	public $table = "schedule";

    
	

}
<div class="brainee-page_container col-lg-12">
	
<div class="brainee-page_container">
	<h2>Identification</h2>

<div class="form-group">
	<div class="col-md-2"></div>
	<div class="col-md-8">
      <label for="comment" style="font-size: 26px">Question:</label>
      <textarea class="form-control" rows="5" id="comment"></textarea>
    <label for="comment" style="font-size: 20px">Answer:</label>
    <input class="form-control" type="text" name="answer">
    <label for="comment" style="font-size: 20px">Score:</label>
    <input class="form-control" type="number" name="score">

    </div>
    <div class="col-md-2"></div>

</div>

</div>
</div>
<center>
	<input type="submit" name="sub" class="btn btn-success" value="Save">
</center>
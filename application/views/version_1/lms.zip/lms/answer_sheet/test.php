<style type="text/css">
	.instruction{
		border-bottom: 1px solid rgba(200, 200, 200, 1);
    	margin-bottom: 30px;
	}
	.question {
	    margin-bottom: 25px;
	}
	.option_container img {
	    max-width: 200px;
	}
	footer {
	    position: fixed;
	    height: 100px;
	    bottom: 0;
	    width: 100%;
	    padding: 20px;
	}
	.footer{
		background-color: #222;
		z-index: 99999;
	}
	.question_container{
		display: none;
		margin-bottom: 100px;
	}
	.question_number {
	    padding: 5px;
	    text-align: center;
	    background-color: #cccccc;
	    border-radius: 10px;
	    margin-bottom: 10px;
	    cursor: pointer;
	    cursor: pointer;
	}
	.question_number:hover {
	    background-color: #222;
	    color: white;
	}
	.active_number{
		background-color: #222;
		color: white;
	}
	.answered_number{
		background-color: #5cb85c;
		color: white;
	}
	.option_container{
		height: auto;
	}
	.question_number_container:last-child{
		margin-bottom: 100px;
	}
</style>
<?php $data = $general_class->data?>
<?php $quiz = $general_class->data['quiz']?>
<?php $attempt = $general_class->data['attempt']?>
<?php $questions_order = json_decode($general_class->data['attempt']['question_order']); ?>
<form method="POST" action="<?php echo $general_class->ben_link('lms/answer_sheet/submit_quiz'); ?>" >
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h1><?php echo $quiz['quiz_name']?></h1>
			</div>
			<input type="hidden" name="id" value="<?php echo $attempt['id']?>">
			<input type="hidden" name="answers" id="answers" value="<?php echo $attempt['id']?>">
			<input type="hidden" name="attempt_id" id="attempt_id" value="<?php echo $attempt['id']?>">
			<?php foreach ($questions_order as $questions_order_key => $questions_order_value) : ?>
					<?php $quiz_part_data['id'] = $questions_order_value->quiz_part_id; ?>
					<?php $question_data['id'] = $questions_order_value->question_id; ?>

					<?php $quiz_part = $general_class->quiz_model->ben_get("quiz_part",$quiz_part_data)[0]; ?>
					<?php $question = $general_class->quiz_model->ben_get("question",$question_data)[0]; ?>

					<div class="col-lg-8 question_container">
						<div class="col-lg-12">
							<div class="instruction"><h3><?php echo $quiz_part['quiz_label'] ?></h3></div>
						</div>
						<div class="col-lg-12">
							<div class="question"><h4><?php echo $question['question'] ?></h4></div>
							<div class="col-lg-12" id="question_container_<?php echo $question['id']; ?>" question_id="<?php echo $question['id']; ?>">
								<?php $general_class->test_display_options($question['id']) ?>
							</div>
						</div>
					</div>
			<?php endforeach; ?>

			<div class="col-lg-4">
				<div class="col-lg-12">
					<?php $number_counter = 1; ?>
					<?php foreach ($questions_order as $questions_order_key => $questions_order_value) : ?>
							<div class="col-lg-3 col-md-2 col-sm-3 col-xs-3 question_number_container" >
								<div class="question_number" id="question_numbering_<?php echo $questions_order_value->question_id ?>"><?php echo $questions_order_key+1?></div>
							</div>
							<?php $number_counter++; ?>
					<?php endforeach; ?>
				</div>
			</div>

			
		</div>
	</div>
	<footer class="footer">
		<div class="col-lg-12">
			<div class="col-lg-1">
				<div class="form-group">
					<button type="button" class="btn btn-warning form-control" id="back">Back</button>
				</div>
			</div>
			<div class="col-lg-1">
				<div class="form-group">
					<button type="button" class="btn btn-success form-control" id="next">Next</button>
				</div>
			</div>
			<div class="col-lg-2">
				<div class="form-group">
					<button class="btn btn-danger form-control" id="submit">Submit Quiz</button>
				</div>
			</div>
		</div>
	</footer>
</form>
<script type="text/javascript">
	$(document).ready(function(){
		var current_question = 0;
		var question_limit = $(".question_container").length;
		var matchingtype_option_list = [];
		var matchingtype_option_hide_list = [];

		$.each($(".matching_type_option_list"),function(key,value){
			matchingtype_option_list.push($(value).val());
		});

		var previous_value;
		$('.matching_type_option_select').change(function(){
			$(this).find("option").each(function(key,value){
				if($(value).is(':selected')){
					if($(value).val()){
						var option_id = $(value).attr("option_id");
						var question_id = $(value).attr("question_id");
						var option_order = $(value).attr("option_order");
						matchingtype_option_hide_list.push(option_id);

						var remove = $(".null_value_"+option_order+"_"+question_id).attr("last_value");
						matchingtype_option_hide_list = jQuery.grep(matchingtype_option_hide_list, function(wwvalue) {
						  return wwvalue != remove;
						});
						$(".null_value_"+option_order+"_"+question_id).attr("last_value",option_id);
						$.each(matchingtype_option_list,function(new_key,new_value){
							$('.option_'+new_value).show();
						});
						$.each(matchingtype_option_hide_list,function(new_key,new_value){
							$('.option_'+new_value).hide();
						});
					}else{
						var remove = $(value).attr("last_value");
						matchingtype_option_hide_list = jQuery.grep(matchingtype_option_hide_list, function(wwvalue) {
						  return wwvalue != remove;
						});
						$.each(matchingtype_option_list,function(new_key,new_value){
							$('.option_'+new_value).show();
						});
						$.each(matchingtype_option_hide_list,function(new_key,new_value){
							$('.option_'+new_value).hide();
						});
					}
				}
			});
			
		});
		function update_answer_sheet(){
			var answer_sheet = {};

			var checked_multiple_choice = $(".multiple_choice:checked");
			var identification = $(".identification");
			var essay = $(".essay");
			var true_or_false = $(".true_or_false:checked");
			var multiple_choice_multiple_answer = $(".multiple_choice_multiple_answer");
			var matching_type = $(".matching_type");

			$.each(matching_type,function(key,value){
				var matching_type_id = $(value).val();
				var option_answer = new Array();
				$.each($(".matching_type_"+matching_type_id),function(matching_type_key,matching_type_value){
					option_answer.push($(matching_type_value).val());
				});
				var answers = option_answer.join();
				
				answer_sheet[matching_type_id] = answers;

			});

			$.each(checked_multiple_choice,function(key,value){
				var question_id = $(value).attr("question_id");
				var checked_value = $(value).val();
				var options_count = $(".option_"+question_id).length;
				var option_answer = new Array();
				for(var x=1;x<=options_count;x++){
					if(x==checked_value){
						var push_value = 1;
					}else{
						var push_value = 0;
					}
					option_answer.push(push_value);
				}
				var answers = option_answer.join();
				answer_sheet[question_id] = answers;
				
			});

			var multiple_choice_multiple_answer_push = [];
			var distinct_multiple_choice_multiple_answer_question_id = $(".distinct_multiple_choice_multiple_answer_question_id");
			var concat_checked_value = "";

			$.each(distinct_multiple_choice_multiple_answer_question_id,function(key,value){
				var question_id = $(value).val();
				var checked = $(".option_"+question_id+":checked");
				var options_count = $(".option_"+question_id);
				var concat = [];

				$.each(checked,function(new_key,new_value){
					concat.push(parseInt($(new_value).val()));
				});

				option_answer = [];
				
				for(var y=1;y<=options_count.length;y++){
					if($.inArray(y,concat)==-1){
						option_answer.push(0);
					}else{
						option_answer.push(1);
					}
				}
				answers = option_answer.join();
				answer_sheet[question_id] = answers;
				
			});

			$.each(true_or_false,function(key,value){
				var question_id = $(value).attr("question_id");
				var checked_value = $(value).val();
				var options_count = $(".option_"+question_id).length;
				var option_answer = new Array();
				for(var x=1;x<=options_count;x++){
					if(x==checked_value){
						var push_value = 1;
					}else{
						var push_value = 0;
					}
					option_answer.push(push_value);
				}
				var answers = option_answer.join();
				answer_sheet[question_id] = answers;
				
			});

			$.each(identification,function(key,value){
				var question_id = $(value).attr("question_id");
				var checked_value = $(value).val();
				var options_count = $(".option_"+question_id).length;
				var option_answer = new Array();
				var answers = $(value).val();
				answer_sheet[question_id] = answers;
				
			});

			$.each(essay,function(key,value){
				var question_id = $(value).attr("question_id");
				var checked_value = $(value).val();
				var options_count = $(".option_"+question_id).length;
				var option_answer = new Array();
				var answers = $(value).val();
				answer_sheet[question_id] = {"answer":answers,"score":"x"};
				
			});

			console.log(answer_sheet);
			var attempt_id = "<?php echo $attempt['id']?>";
			answer_sheet = JSON.stringify(answer_sheet);
			$("#answers").val(answer_sheet);
			$("#attempt_id").val(attempt_id);
			$.ajax({
			  	url: "<?php echo $general_class->ben_link('lms/answer_sheet/ajax_saving'); ?>",
			  	type: "POST",
			  	data:{attempt_id:attempt_id,answers:answer_sheet},
			}).done(function(response) {
			  	console.log(response);
			}).fail(function() {
			  	console.log("fail bro ez");
			});
		}
		$(".multiple_choice").click(function(){
			var form_group = $(this).parent().parent().parent().parent();
			var question_id = $(form_group).attr("question_id");
			var choices_count = form_group.find("input").length;
			$("#question_numbering_"+question_id).addClass("answered_number");
		});

		$(".question_container").eq(0).show();
		$(".question_number_container").eq(0).find(".question_number").addClass("active_number");

		$("#next").click(function(){
			$(".question_container").eq(current_question).hide();
			$(".question_number_container").eq(current_question).find(".question_number").removeClass("active_number");
			if(current_question<question_limit){
				current_question = current_question+1;
			}
			$(".question_container").eq(current_question).show();
			$(".question_number_container").eq(current_question).find(".question_number").addClass("active_number");

			update_answer_sheet();
		});

		$("form").submit(function(){
			update_answer_sheet();
		});

		$(".question_number").click(function(){
			$(".question_container").eq(current_question).hide();
			$(".question_number_container").eq(current_question).find(".question_number").removeClass("active_number");
			current_question = $(this).parent().index();
			$(".question_number_container").eq(current_question).find(".question_number").addClass("active_number");
			$(".question_container").eq(current_question).show();
			update_answer_sheet();
		});

		$("#back").click(function(){
			$(".question_container").eq(current_question).hide();
			$(".question_number_container").eq(current_question).find(".question_number").removeClass("active_number");
			if(current_question>0){
				current_question = current_question-1;
			}
			
			$(".question_container").eq(current_question).show();
			$(".question_number_container").eq(current_question).find(".question_number").addClass("active_number");
			update_answer_sheet();
		});

	});
</script>


<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script> -->
<!-- <script src="<?php echo $general_class->ben_js('general/parallax.min.js')?>"></script> -->
<style type="text/css">
    .parallax-window {
        min-height: 800px;
        background: transparent;
    }
</style>
<div class="parallax-window" data-parallax="scroll" data-image-src="http://www.steps-manda.com/image/front.jpg"></div>
<div class="parallax-window" data-parallax="scroll" data-image-src="http://www.steps-manda.com/image/front.jpg"></div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="<?php echo $general_class->ben_js('general/parallax.js')?>"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
    //$('.parallax-window').parallax({imageSrc: 'http://www.steps-manda.com/image/front.jpg'});
</script>

</div>
</section>

<!-- Jquery Core Js -->
<script src="<?php echo $general_class->ben_resources('sms'); ?>/plugins/jquery/jquery.min.js"></script>

<!-- Bootstrap Core Js -->
<script src="<?php echo $general_class->ben_resources('sms'); ?>/plugins/bootstrap/js/bootstrap.js"></script>

<!-- Select Plugin Js -->
<script src="<?php echo $general_class->ben_resources('sms'); ?>/plugins/bootstrap-select/js/bootstrap-select.js"></script>

<!-- Slimscroll Plugin Js -->
<script src="<?php echo $general_class->ben_resources('sms'); ?>/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

<!-- Waves Effect Plugin Js -->
<script src="<?php echo $general_class->ben_resources('sms'); ?>/plugins/node-waves/waves.js"></script>

<!-- Jquery CountTo Plugin Js -->
<script src="<?php echo $general_class->ben_resources('sms'); ?>/plugins/jquery-countto/jquery.countTo.js"></script>

<!-- Custom Js -->
<script src="<?php echo $general_class->ben_resources('sms'); ?>/js/admin.js"></script>
<script src="<?php echo $general_class->ben_resources('sms'); ?>/js/pages/index.js"></script>

<!-- Demo Js -->
<script src="<?php echo $general_class->ben_resources('sms'); ?>/js/demo.js"></script>

<!-- Jquery Nestable -->
<script src="<?php echo $general_class->ben_resources('sms'); ?>/plugins/nestable/jquery.nestable.js"></script>

<script src="<?php echo $general_class->ben_resources('sms'); ?>/js/pages/ui/sortable-nestable.js"></script>

<script type="text/javascript">
    $("#student_tree").nestable({
        collapsedClass:'dd-collapsed',
    }).nestable('collapseAll');
</script>
</body>

</html>
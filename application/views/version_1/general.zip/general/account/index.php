<div class="brainee-page_container col-lg-12">
	<?php $general_class->ben_titlebar();?>
	<?php $datatable = array(
			"th"=>array(
				"Username",
				"Account Type",
				"Company Name",
				"Logged",
			),
			"td"=>array(
				"username",
				"account_type_name",
				"company_name",
				"logged",
			),
			"data"=>$data,
		);
	?>
	<?php $general_class->ben_datatable($datatable);?>
</div>
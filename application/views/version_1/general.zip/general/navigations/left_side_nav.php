    <style>
    .navbar-brand img{
        width:90px;
    }
        </style>
    </style>
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="index.html" style="top: -10px;position: relative;width: 500px;"><img style="height: 41px;display: inline;" src="https://chamilo.org/wp-content/uploads/2018/09/chamilo_logo.png"><p style="display: inline;top: -7px;position: relative;left: 10px;">San Isidro Catholic School</p><p style="display: block;top: -24px;position: relative;left: 100px;font-size: 12px;">Learning Management System</p></a>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
                    <!-- Call Search -->
                    <li><a href="javascript:void(0);" class="js-search" data-close="true"><i class="material-icons">search</i></a></li>
                    <!-- #END# Call Search -->
                    <!-- Notifications -->
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button">
                            <i class="material-icons">notifications</i>
                            <span class="label-count">7</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">NOTIFICATIONS</li>
                            <li class="body">
                                <ul class="menu">
                                    <li>
                                        <a href="javascript:void(0);">
                                            <div class="icon-circle bg-light-green">
                                                <i class="material-icons">person_add</i>
                                            </div>
                                            <div class="menu-info">
                                                <h4>12 new members joined</h4>
                                                <p>
                                                    <i class="material-icons">access_time</i> 14 mins ago
                                                </p>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <div class="icon-circle bg-cyan">
                                                <i class="material-icons">add_shopping_cart</i>
                                            </div>
                                            <div class="menu-info">
                                                <h4>4 sales made</h4>
                                                <p>
                                                    <i class="material-icons">access_time</i> 22 mins ago
                                                </p>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <div class="icon-circle bg-red">
                                                <i class="material-icons">delete_forever</i>
                                            </div>
                                            <div class="menu-info">
                                                <h4><b>Nancy Doe</b> deleted account</h4>
                                                <p>
                                                    <i class="material-icons">access_time</i> 3 hours ago
                                                </p>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <div class="icon-circle bg-orange">
                                                <i class="material-icons">mode_edit</i>
                                            </div>
                                            <div class="menu-info">
                                                <h4><b>Nancy</b> changed name</h4>
                                                <p>
                                                    <i class="material-icons">access_time</i> 2 hours ago
                                                </p>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <div class="icon-circle bg-blue-grey">
                                                <i class="material-icons">comment</i>
                                            </div>
                                            <div class="menu-info">
                                                <h4><b>John</b> commented your post</h4>
                                                <p>
                                                    <i class="material-icons">access_time</i> 4 hours ago
                                                </p>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <div class="icon-circle bg-light-green">
                                                <i class="material-icons">cached</i>
                                            </div>
                                            <div class="menu-info">
                                                <h4><b>John</b> updated status</h4>
                                                <p>
                                                    <i class="material-icons">access_time</i> 3 hours ago
                                                </p>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <div class="icon-circle bg-purple">
                                                <i class="material-icons">settings</i>
                                            </div>
                                            <div class="menu-info">
                                                <h4>Settings updated</h4>
                                                <p>
                                                    <i class="material-icons">access_time</i> Yesterday
                                                </p>
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="footer">
                                <a href="javascript:void(0);">View All Notifications</a>
                            </li>
                        </ul>
                    </li>
                    <!-- #END# Notifications -->
                    <!-- Tasks -->
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button">
                            <i class="material-icons">flag</i>
                            <span class="label-count">9</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">TASKS</li>
                            <li class="body">
                                <ul class="menu tasks">
                                    <li>
                                        <a href="javascript:void(0);">
                                            <h4>
                                                Footer display issue
                                                <small>32%</small>
                                            </h4>
                                            <div class="progress">
                                                <div class="progress-bar bg-pink" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 32%">
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <h4>
                                                Make new buttons
                                                <small>45%</small>
                                            </h4>
                                            <div class="progress">
                                                <div class="progress-bar bg-cyan" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 45%">
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <h4>
                                                Create new dashboard
                                                <small>54%</small>
                                            </h4>
                                            <div class="progress">
                                                <div class="progress-bar bg-teal" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 54%">
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <h4>
                                                Solve transition issue
                                                <small>65%</small>
                                            </h4>
                                            <div class="progress">
                                                <div class="progress-bar bg-orange" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 65%">
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <h4>
                                                Answer GitHub questions
                                                <small>92%</small>
                                            </h4>
                                            <div class="progress">
                                                <div class="progress-bar bg-purple" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 92%">
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="footer">
                                <a href="javascript:void(0);">View All Tasks</a>
                            </li>
                        </ul>
                    </li>
                    <!-- #END# Tasks -->
                    
                </ul>
            </div>
        </div>
    </nav>
    <!-- #Top Bar -->

    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="image">
                    <img src="<?php echo $general_class->ben_resources('sms'); ?>/images/user.png" width="48" height="48" alt="User" />
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $general_class->session->userdata('first_name'); ?> <?php echo $general_class->session->userdata('last_name'); ?></div>
                    <div class="email"><?php echo $general_class->session->userdata('email_address'); ?></div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            <li><a href="javascript:void(0);"><i class="material-icons">person</i>Profile</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="javascript:void(0);"><i class="material-icons">group</i>Handled Subjects</a></li>
                            <li><a href="javascript:void(0);"><i class="material-icons">security</i>Change Password</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="<?php echo $general_class->ben_link('general/login/logout')?>"><i class="material-icons">input</i>Sign Out</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="header">MAIN NAVIGATION</li>

                    <?php if($general_class->session->userdata('account_type_name')=="school coordinator"):?>      
                        <li class="active">
                            <a href="<?php echo $general_class->ben_link('general/dashboard/sms_index')?>">
                                <i class="material-icons">home</i>
                                <span>Home</span>
                            </a>
                        </li>
                        

                        <li>
                            <a href="javascript:void(0);" class="menu-toggle">
                                <i class="material-icons">assignment</i>
                                <span>Registrar</span>
                            </a>
                            <ul class="ml-menu">
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Admission</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Enrollment</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" class="menu-toggle">
                                        <span>Form 138</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a href="/brainee/index.php/version_1/sms/grading/form_138">Individual</a>
                                        </li>
                                        <li>
                                            <a href="/brainee/index.php/version_1/sms/grading/form_138_section">Section</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Student Profile</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Student Evaluation</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                
                                
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Student ID</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Classroom Management</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Parent Profile</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>School Service</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Tagging of Graduates</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a class="menu-toggle">
                                <i class="material-icons">person</i>
                                <span>Human Resource</span>
                            </a>
                            <ul class="ml-menu">
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Employee's Profile (201) </span>
                                    </a>
                                    <ul class="ml-menu">
       
                                        <li>
                                            <a> Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Employee's Attendance</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Timekeeping</a>
                                        </li>
                                        <li>
                                            <a>Absences</a>
                                        </li>
                                        <li>
                                            <a>Lates</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Employees Records</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Salary</a>
                                        </li>
                                        <li>
                                            <a>Benefits</a>
                                        </li>
                                        <li>
                                            <a>Loans</a>
                                        </li>
                                        <li>
                                            <a>Advances</a>
                                        </li>
                                        <li>
                                            <a>Subject Loads</a>
                                        </li>
                                        <li>
                                            <a>Trainings</a>
                                        </li>
                                        <li>
                                            <a>Evaluation</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Leave Management</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Leaves</a>
                                        </li>
                                        <li>
                                            <a>Sick Leave</a>
                                        </li>
                                        <li>
                                            <a>Maternity Leave</a>
                                        </li>
                                        <li>
                                            <a>Paternity Leave</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Employee's Evaluation</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Teaching</a>
                                        </li>
                                        <li>
                                            <a>Non Teaching</a>
                                        </li>
                                        <li>
                                            <a></a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Applicant records / Process</span>
                                    </a>
                                    <ul class="ml-menu">
                                        
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                
                            </ul>
                        </li>
                        
                        <li>
                            <a href="javascript:void(0);" class="menu-toggle">
                                <i class="material-icons">attach_money</i>
                                <span>Accounting</span>
                            </a>
                            <ul class="ml-menu">
                                
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Payroll System</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Attendance</a>
                                        </li>
                                        <li>
                                            <a>Leave</a>
                                        </li>
                                        <li>
                                            <a>Absences</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Employee's Loans / Benefits</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Cashiering</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Inventories</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Enrollment</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <<li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Purchasing</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="menu-toggle">
                                <i class="material-icons">face</i>
                                <span>Academic</span>
                            </a>
                            <ul class="ml-menu">
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Grading System</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Campus Ebook</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>Media Center (Library)</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Under Construction</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" class="menu-toggle">
                                        <span>School Settings</span>
                                    </a>
                                    <ul class="ml-menu">
                                        <li>
                                            <a>Subjects</a>
                                        </li>
                                        <li>
                                            <a>Sections</a>
                                        </li>
                                        <li>
                                            <a>Grade Level</a>
                                        </li>
                                    </ul>
                                </li>
                                
                                
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if(strtolower($general_class->session->userdata('account_type_name'))=="student"):?>
                            <li>
                                <a href="javascript:void(0);" class="menu-toggle">
                                    <img class="material-icons" src="https://s24255.pcdn.co/wp-content/uploads/2015/12/chamilo.jpg" style="height: 26px;">
                                    <span>SICS - LMS</span>
                                </a>
                                <ul class="ml-menu">
                                    <li>
                                        <a href="javascript:void(0);" class="menu-toggle">
                                            <span>Lessons</span>
                                        </a>
                                        <ul class="ml-menu">
                                            <li>
                                                <a href="<?php echo $general_class->ben_link('lms/lesson/assigned_lesson')?>">Assigned Lessons</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" class="menu-toggle">
                                            <span>Assessment</span>
                                        </a>
                                        <ul class="ml-menu">
                                            <li>
                                                <a href="<?php echo $general_class->ben_link('lms/quiz/student_assigned_quizzes')?>" class="waves-effect waves-block">
                                                    <span>Assigned Quizzes</span>
                                                </a>
                                                <a href="<?php echo $general_class->ben_link('lms/quiz/student_quiz_history')?>" class="waves-effect waves-block">
                                                    <span>Quizzes History</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <!-- <li>
                                        <a href="javascript:void(0);" class="menu-toggle">
                                            <span>Assignment</span>
                                        </a>
                                        <ul class="ml-menu">
                                            <li>
                                                <a href="pages/widgets/cards/basic.html">Enrollment</a>
                                            </li>
                                            <li>
                                                <a href="pages/widgets/cards/colored.html">Cashiering</a>
                                            </li>
                                            <li>
                                                <a href="pages/widgets/cards/no-header.html"></a>
                                            </li>
                                        </ul>
                                    </li> -->
                                    
                                    
                                </ul>
                            </li>
                        <?php else: ?>
                            <li>
                                <a href="javascript:void(0);" class="menu-toggle">
                                    <img class="material-icons" src="https://s24255.pcdn.co/wp-content/uploads/2015/12/chamilo.jpg" style="height: 26px;">
                                    <span>SICS - LMS</span>
                                </a>
                                <ul class="ml-menu">
                                    <li>
                                        <a href="javascript:void(0);" class="menu-toggle">
                                            <span>Lessons</span>
                                        </a>
                                        <ul class="ml-menu">
                                            <li>
                                                <a href="<?php echo $general_class->ben_link('lms/lesson/packages')?>">Lesson Packages</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo $general_class->ben_link('lms/lesson/create')?>">Lesson Creation</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo $general_class->ben_link('lms/lesson/lesson_bank')?>">Lesson Bank</a>
                                            </li>

                                        </ul>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" class="menu-toggle">
                                            <span>Assessment</span>
                                        </a>
                                        <ul class="ml-menu">
                                            <li>
                                                <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block">
                                                    <span>Quiz Packages</span>
                                                </a>
                                                <ul class="ml-menu">
                                                    <li>
                                                        <a href="<?php echo $general_class->ben_link('lms/quiz/formative')?>">Formative</a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo $general_class->ben_link('lms/quiz/mastery')?>">Mastery</a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo $general_class->ben_link('lms/quiz/index')?>">Summative Test</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="<?php echo $general_class->ben_link('lms/quiz/create')?>">
                                                    <span>Quiz Creation</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo $general_class->ben_link('lms/quiz/create')?>">
                                                    <span>Quiz Bank</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <!-- <li>
                                        <a href="javascript:void(0);" class="menu-toggle">
                                            <span>Assignment</span>
                                        </a>
                                        <ul class="ml-menu">
                                            <li>
                                                <a href="pages/widgets/cards/basic.html">Enrollment</a>
                                            </li>
                                            <li>
                                                <a href="pages/widgets/cards/colored.html">Cashiering</a>
                                            </li>
                                            <li>
                                                <a href="pages/widgets/cards/no-header.html"></a>
                                            </li>
                                        </ul>
                                    </li> -->
                                    <!-- <li>
                                        <a href="javascript:void(0);" class="menu-toggle">
                                            <span>School Settings</span>
                                        </a>
                                        <ul class="ml-menu">
                                            <li>
                                                <a href="pages/widgets/cards/basic.html">Subjects</a>
                                            </li>
                                            <li>
                                                <a href="pages/widgets/cards/colored.html">Sections</a>
                                            </li>
                                            <li>
                                                <a href="pages/widgets/cards/colored.html">Grade Level</a>
                                            </li>
                                            <li>
                                                <a href="pages/widgets/cards/no-header.html"></a>
                                            </li>
                                        </ul>
                                    </li> -->
                                    
                                    
                                </ul>
                        </li>
                    <?php endif; ?>
                    
                    
                    
                    
                </ul>
            </div>
            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
                <div class="copyright">
                    &copy; 2018 - 2019 <a href="javascript:void(0);">Inspired By Chamilo</a>.
                </div>
                <div class="version">
                    <b>Version: </b> 3.0.0
                </div>
            </div>
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
    </section>
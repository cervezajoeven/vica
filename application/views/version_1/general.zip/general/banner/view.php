<div class="container">
	<div class="row">
		<div class="col-12-lg">
			<h1>Memos</h1>
		</div>
		<div class="col-4-lg">
			Image1
		</div>
		<div class="col-4-lg">
			Image2
		</div>
		<div class="col-4-lg">
			Image3
		</div>
	</div>
</div>
<?php
class Grade_model extends BEN_Model {

	public $table = "grade";
	
}

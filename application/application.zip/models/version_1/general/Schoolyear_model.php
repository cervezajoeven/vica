<?php
class Schoolyear_model extends BEN_Model {

	public $table = "schoolyear";

	

}
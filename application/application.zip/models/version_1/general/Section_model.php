<?php
class Section_model extends BEN_Model {

	public $table = "section";
	
}

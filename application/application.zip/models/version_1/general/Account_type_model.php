<?php
class Account_type_model extends BEN_Model {

	public $table = "account_type";

	

}
<?php
class Quiz_question_model extends BEN_Model {

	public $table = "quiz_question";
	
}
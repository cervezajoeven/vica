<?php
class Company_model extends BEN_Model {

        

}
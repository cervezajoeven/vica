<?php $data = $general_class->data; ?>
<div class="form-group">
	<textarea class="form-control" readonly="" value="">(Essay has no definite answer)</textarea>
</div>
<?php $data = $general_class->data; ?>
<?php $options = $data['option_data'][0]; ?>
<div class="form-group">
	<input type="text" class="form-control" name="identification_<?php echo $options['id']; ?>" value="">
</div>


<?php $data = $general_class->data; ?>
<?php $options = $data['option_data'][0]; ?>
<div class="form-group">
	<textarea class="form-control" name="essay_<?php echo $options['id']; ?>"></textarea>
</div>
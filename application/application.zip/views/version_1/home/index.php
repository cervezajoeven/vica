<div class="container">
	<div class="row">

		<?php echo $general_class->ben_open_form("login"); ?>
			<div class="form-group">
				<h5>Username</h5>
				<input type="text" name="username" class="form-control" value="" size="50" />
			</div>
			<div class="form-group">
				<h5>Password</h5>
				<input type="password" name="password" class="form-control" value="" size="50" />
			</div>
			<div class="form-group">
				<input type="submit" class="form-control" value="Submit" />
			</div>

		</form>

	</div>
</div>
<style type="text/css">
	.portal{
		margin-top: 20px;
	}
	.portal img {
		width: 100%;
		cursor: pointer;
	}
</style>
<div class="container portal">
	<div class="row">
		<div class="col-lg-1">
		</div>
		<div class="col-lg-4">
			<a href="<?php echo $general_class->ben_link('general/dashboard/sms_index'); ?>"><img src="https://4.imimg.com/data4/FE/PP/MY-22855200/restaurant-billing-system-software-500x500.png"></a>
		</div>
		<div class="col-lg-2">
		</div>

		<div class="col-lg-4">

			<a href="<?php echo $general_class->ben_link('general/dashboard/index'); ?>"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAe1BMVEUAAAD////e3t64uLidnZ3u7u5hYWH8/Pyurq7T09OoqKjr6+vk5OS7u7vb29vDw8PMzMxCQkJmZmZwcHCQkJD39/dUVFSGhoY6OjpQUFA1NTWysrKVlZVcXFwcHBx+fn4jIyMODg4uLi52dnZ/f38WFhZJSUkqKiqampqArJBWAAAGN0lEQVR4nO2daXuyOhCGQUHEDVRc6m61ff3/v/CAVstkIYtJ7en13N9UTPJAMslMBgjCMEy6213wB3nrJaW6IAzTV7fEI2ml8C8LrCQG4avb4Jkk6L66CZ7pBdtXN8Ez8+D46iZ45q/rAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAID/J6tTcYmiTbHY/nt1U9yzKrJ+9fSQO8lgPfVS0XtnetqfppOxl9KltUb9UERrIbnHfxxlefRuWs34kse10mdpr/Nsy/XopEJ5NzLRuc5vvw1NapmvY1H5afHhSIaUyaBB37UNb8w/Ph5NHWjXcmqoJfd6JZdN1+/RBHqaa39p69XyqTiLAz9DvqKroa/iXPvPtv6D1ljsqStI/Rjvpdi+iMi//7Wuf19oVKPTTcJw4kHgVFtfyexhcUb1r9fqalTj/I776aMwEVhyHyut+pfqgTiSlccyci0wMhQYhp82Ctey0niWbgVqjH6WloXCjkH5C6cCN+YC7yfZSKG+LQvDjUuBciMzi+N4JvltYazwZCDQ6TV8F4vLzsvbEwnft5dccEBhrFDbzFSsHCoU9Z2MXZztuebtTRUeuFr67fP8UP0yP3Vb9CeXzwsUrGSGB8Fxb4zGg6nCM1NLTue842nEle6ET/7MymbbPWnf7TsDhcypFDww7/M+GhK2Cz0D1/savKBjTc/XU0MNFNL1mtiF6FTNmTl9HiI3RTXbsPuU/Vi2GSgkCzb5OFsa+9LNsOvEk+L4eZqEYdx7fDZQSCxar/FQh7CXUMc7WNYdxF+vkJnoNJwDBttemjce6hAqsG9egK2lSSwbbArjM1nYaAOF1LH4oefH0qkisyjBQCFzOp0urWUcaZ02S0EDhWNaW5i7XHpKoJbUailosvLmQqTc6tc51LNXTYVCTBQK/OxB4feJ6nSusCrCRCHvXFS0Lh43LcgMZRf7MfLx20KJ5Rqw7eu51aQaO/NtFolKQhnJ0Es0n9RxVh8vwExhY1A2jqxa0AQNX9iFmQ3jpYqo5dqx3aETlN1QMFSojJi6XZFT935uVYapwuCikDhzuWWxJEXbjXRjhcFEIdHlZdyRgu127cwVBjvV9pPN+lgCKfdiVYSFwiDYKnag3ElMni/WSmHZVZnwKIOzjkqcp9iqCEuFpSEfyqd/W6PAMySlWjkz1gpLpqLNghszm7YIoD6p1ZLiGYUl07Zk40cnJKYBnfKtuumTCqtGRCK7YxEyEkJP4N6ihOcVliy7/JW0W4Bw0IFocxGdKAwESUSOzCkTELYYia4UchvRrlIVmN5hnh7gTiG7nHuqrG+Y0Il5P3WoMMh8KGRDJy3lP/4telFt+W+icDW87upI39NE/WNXsUZqa9QhxdvxyWO6MlC4+DoqkZlJkiPnLCuK+heqqzh+jNv7Pqq+wsX3cZK4JbV7zlKGuCDmTD4T1Rp530nVVkhOpdho021wdwENfrKV7HMv6S7H7UtthdS3b33yR/ixpQHb+68kEZ+MPM6Yg24es7ZC1u3N2a7CBKn0M47VCBNnMxIuORR8tk9kppB3CPu11PUJ50s53X2T5CqNusVkPu+cNkNh1nmPb3jTFrI4dDEbpXk6EvkXTqPgR1nqWiOCvLYqDY5j0L7afcP0Rzt/XIo4s03BjlcoIzOvwy4CL4dPjNJqta7C6zLa6CI6voQBGzo1aIKewuugZY1xE468wzors7H48G00FV5nN32J7vdoKvRuE7jxbTR1FV4nH92O6jAkTNBO109kvkUDt6V6pymC6F1gORj1boYgDdDN+/1axh41eqrXhLCzejQO6FSseyfRI+tirjiNse8XNW+a+1GfdXze9ATWrX/T/XHJT+QR7eVDi1stB7oGkm5szYfivtJye5OFnFUkGl25JJyqM3j5odXpMv9L0uIHcqTqLYiyQfzVY+NWe9EwBSvngJnk3HSKdTvL86zdXUwOXlSo2R3eD2pf+7iPmvBxpx0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAF9In0/4RzgGHp7T86vYBj/2WqwX0Q1+6qVRryIMnL4H8veRlgr/tMQ0rBSGSc/7G5Vewce2Wz125T+Bpj57GCStJwAAAABJRU5ErkJggg==">
			</a>
		</div>
		<div class="col-lg-1">
		</div>

	</div>
</div>
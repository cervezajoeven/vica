<!-- <link rel="stylesheet" type="text/css" href="<?php echo $general_class->ben_resources('lms'); ?>/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $general_class->ben_resources('lms'); ?>/responsive.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $general_class->ben_resources('lms'); ?>/select.dataTables.min.css">
<script type="text/javascript" src="<?php echo $general_class->ben_resources('lms'); ?>/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo $general_class->ben_resources('lms'); ?>/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="<?php echo $general_class->ben_resources('lms'); ?>/dataTables.select.min.js"></script> -->


<link rel="stylesheet" type="text/css" href="<?php echo $general_class->ben_resources('datatables'); ?>/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $general_class->ben_resources('datatables'); ?>/select.dataTables.min.css">
<script type="text/javascript" src="<?php echo $general_class->ben_resources('datatables'); ?>/jquery-3.3.1.js"></script>
<script type="text/javascript" src="<?php echo $general_class->ben_resources('datatables'); ?>/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo $general_class->ben_resources('datatables'); ?>/dataTables.select.min.js"></script>

<script type="text/javascript" src="<?php echo $general_class->ben_resources('datatables'); ?>/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?php echo $general_class->ben_resources('datatables'); ?>/buttons.flash.min.js"></script>
<script type="text/javascript" src="<?php echo $general_class->ben_resources('datatables'); ?>/jszip.min.js"></script>
<script type="text/javascript" src="<?php echo $general_class->ben_resources('datatables'); ?>/pdfmake.min.js"></script>
<script type="text/javascript" src="<?php echo $general_class->ben_resources('datatables'); ?>/vfs_fonts.js"></script>
<script type="text/javascript" src="<?php echo $general_class->ben_resources('datatables'); ?>/buttons.html5.min.js"></script>
<script type="text/javascript" src="<?php echo $general_class->ben_resources('datatables'); ?>/buttons.print.min.js"></script>
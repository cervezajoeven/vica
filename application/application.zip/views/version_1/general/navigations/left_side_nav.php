    <style>

    .navbar{
        background-color: #24904f!important;
    }
    .sidebar .user-info {
    
        background: url("<?php echo $general_class->ben_resources('sms/images/').'/user-img-background2.jpg'?>") no-repeat no-repeat;
        background-size: 100% 100%;
    }
    .bars::before{
        width: 200px;
    }
    .list{
        padding-bottom: 50px;
    }
    #leftsidebar{
        width: 250px;
    }
    section.content{
        margin: 100px 15px 0 275px;
    }
    </style>
    <!-- Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand"><?php echo $school_status['shortcut'] ?> CMS</a>
            </div>

            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
                    <!-- Notifications -->
                    <li class="dropdown">
                        <a href="<?php echo $general_class->ben_link('general/login/logout')?>" id="sign_out" class="dropdown-toggle" role="button">
                            <i class="material-icons">power_settings_new</i>
                            <span class="label-count"></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

    </nav>
    <!-- #Top Bar -->



    <section>
        <!-- <pre> -->
        <?php //print_r($general_class->section_model->all("subject")); ?>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <!-- <div class="user-info">
                <div class="image">
                    <img src="<?php echo $general_class->ben_resources('sms/images/').'/user-img-background2.jpg'?>" width="48" height="48" alt="User" />
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $general_class->session->userdata('first_name'); ?> <?php echo $general_class->session->userdata('last_name'); ?></div>
                    <div class="email"><?php echo $general_class->session->userdata('email_address'); ?></div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            <li><a href="javascript:void(0);"><i class="material-icons">person</i>Profile</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="javascript:void(0);"><i class="material-icons">security</i>Change Password</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="<?php echo $general_class->ben_link('general/login/logout')?>"><i class="material-icons">input</i>Sign Out</a></li>
                        </ul>
                    </div>
                </div>
            </div> -->
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="header"><?php echo $school_status['shortcut'] ?> - Learning Management System</li>

     
                    <li>
                        <a href="<?php echo $general_class->ben_link('general/dashboard/sms_index')?>">
                            <i class="material-icons">home</i>
                            <span>Home</span>
                        </a>
                    </li>



                    <?php if(strtolower($general_class->session->userdata('account_type_name'))=="student"):?>
                            <li class="<?php if(in_array('assigned_lesson', $general_class->toggled)): echo 'active'; endif; ?>">
                                <a href="<?php echo $general_class->ben_link('lms/lesson/assigned_lesson')?>" class="">
                                    <i class="material-icons">folder</i>
                                    <span>Lessons</span>
                                </a>
                            </li>

                            <li class="<?php if(in_array('student_assigned_quizzes', $general_class->toggled)): echo 'active'; endif; ?>">
                                <a href="<?php echo $general_class->ben_link('lms/quiz/student_assigned_quizzes')?>" class="">
                                    <i class="material-icons">assessment</i>
                                    <span>Quizzes</span>
                                </a>
                            </li>

                            <li class="<?php if(in_array('student_quiz_history', $general_class->toggled)): echo 'active'; endif; ?>">
                                <a href="<?php echo $general_class->ben_link('lms/quiz/student_quiz_history')?>" class="">
                                    <i class="material-icons">assignment</i>
                                    <span>Quiz History</span>
                                </a>
                            </li>
                        <?php elseif($general_class->session->userdata('account_type_id')==3): ?>
                            <li class="<?php if(in_array('lessons', $general_class->toggled)): echo 'active'; endif; ?>">
                                <a href="javascript:void(0);" class="menu-toggle">
                                    <i class="material-icons">book</i>
                                    <span>Lesson</span>
                                </a>
                                <ul class="ml-menu">
                                    <li class="<?php if(in_array('lesson_packages', $general_class->toggled)): echo 'active'; endif; ?>">

                                        <a href="<?php echo $general_class->ben_link('lms/lesson/packages')?>" class="<?php if(in_array('toggled', $general_class->toggled)): echo 'active'; endif; ?>">

                                            <span>Lesson Packages</span>
                                        </a>
                                    </li>
                                    <li class="<?php if(in_array('lesson_bank', $general_class->toggled)): echo 'active'; endif; ?>">
                                        <a href="<?php echo $general_class->ben_link('lms/lesson/lesson_bank')?>" class=" <?php if(in_array('toggled', $general_class->toggled)): echo 'active'; endif; ?>">
                                            <span>Shared Lessons</span>
                                        </a>
                                    </li>
                                    <li class="<?php if(in_array('my_lessons', $general_class->toggled)): echo 'active'; endif; ?>">
                                        <a href="<?php echo $general_class->ben_link('lms/lesson/index')?>" class="<?php if(in_array('toggled', $general_class->toggled)): echo 'active'; endif; ?>">
                                            <span>My Lessons</span>
                                        </a>
                                    </li>
                                    
                                </ul>
                            </li>

                            <li class="<?php if(in_array('assessment', $general_class->toggled)): echo 'active'; endif; ?>">
                                <a href="javascript:void(0);" class="menu-toggle">
                                    <i class="material-icons">assessment</i>
                                    <span>Assessment</span>
                                </a>
                                <ul class="ml-menu">
                                    <li class="<?php if(in_array('quiz_packages', $general_class->toggled)): echo 'active'; endif; ?>">
                                        <a href="<?php echo $general_class->ben_link('lms/quiz/packages')?>" class="<?php if(in_array('quiz_packages', $general_class->toggled)): echo 'toggled'; endif; ?>">
                                            <span>Quiz Packages</span>
                                        </a>
                                    </li>
                                    <li class="<?php if(in_array('shared_quizzes', $general_class->toggled)): echo 'active'; endif; ?>">
                                        <a href="<?php echo $general_class->ben_link('lms/quiz/quiz_bank')?>" class="<?php if(in_array('shared_quizzes', $general_class->toggled)): echo 'toggled'; endif; ?>">
                                            <span>Shared Quizzes</span>
                                        </a>
                                        
                                    </li>
                                    <li class="<?php if(in_array('my_quizzes', $general_class->toggled)): echo 'active'; endif; ?>">
                                        <a href="<?php echo $general_class->ben_link('lms/quiz/index')?>" class="<?php if(in_array('my_quizzes', $general_class->toggled)): echo 'toggled'; endif; ?>">
                                            <span>My Quizzes</span>
                                        </a>
                                        
                                    </li>
                                </ul>
                            </li>
                            <li class="<?php if(in_array('lessons', $general_class->toggled)): echo 'active'; endif; ?>">
                                <a href="javascript:void(0);">
                                    <i class="material-icons">book</i>
                                    <span>Schedules</span>
                                </a>
                                
                            </li>

                            <li class="<?php if(in_array('lessons', $general_class->toggled)): echo 'active'; endif; ?>">
                                <a href="<?php echo $general_class->ben_link('general/account/index') ?>">
                                    <i class="material-icons">book</i>
                                    <span>Accounts</span>
                                </a>
                                
                            </li>
                        <?php else: ?>
                            <li class="<?php if(in_array('lessons', $general_class->toggled)): echo 'active'; endif; ?>">
                                <a href="javascript:void(0);" class="menu-toggle">
                                    <i class="material-icons">book</i>
                                    <span>Lesson</span>
                                </a>
                                <ul class="ml-menu">
                                    <li class="<?php if(in_array('lesson_packages', $general_class->toggled)): echo 'active'; endif; ?>">

                                        <a href="<?php echo $general_class->ben_link('lms/lesson/packages')?>" class="<?php if(in_array('toggled', $general_class->toggled)): echo 'active'; endif; ?>">

                                            <span>Lesson Packages</span>
                                        </a>
                                    </li>
                                    <li class="<?php if(in_array('lesson_bank', $general_class->toggled)): echo 'active'; endif; ?>">
                                        <a href="<?php echo $general_class->ben_link('lms/lesson/lesson_bank')?>" class=" <?php if(in_array('toggled', $general_class->toggled)): echo 'active'; endif; ?>">
                                            <span>Shared Lessons</span>
                                        </a>
                                    </li>
                                    <li class="<?php if(in_array('my_lessons', $general_class->toggled)): echo 'active'; endif; ?>">
                                        <a href="<?php echo $general_class->ben_link('lms/lesson/index')?>" class="<?php if(in_array('toggled', $general_class->toggled)): echo 'active'; endif; ?>">
                                            <span>My Lessons</span>
                                        </a>
                                    </li>
                                    
                                </ul>
                            </li>


                            <li class="<?php if(in_array('assessment', $general_class->toggled)): echo 'active'; endif; ?>">
                                <a href="javascript:void(0);" class="menu-toggle">
                                    <i class="material-icons">assessment</i>
                                    <span>Assessment</span>
                                </a>
                                <ul class="ml-menu">
                                    <li class="<?php if(in_array('quiz_packages', $general_class->toggled)): echo 'active'; endif; ?>">
                                        <a href="<?php echo $general_class->ben_link('lms/quiz/packages')?>" class="<?php if(in_array('quiz_packages', $general_class->toggled)): echo 'toggled'; endif; ?>">
                                            <span>Quiz Packages</span>
                                        </a>
                                    </li>
                                    <li class="<?php if(in_array('shared_quizzes', $general_class->toggled)): echo 'active'; endif; ?>">
                                        <a href="<?php echo $general_class->ben_link('lms/quiz/quiz_bank')?>" class="<?php if(in_array('shared_quizzes', $general_class->toggled)): echo 'toggled'; endif; ?>">
                                            <span>Shared Quizzes</span>
                                        </a>
                                        
                                    </li>
                                    <li class="<?php if(in_array('my_quizzes', $general_class->toggled)): echo 'active'; endif; ?>">
                                        <a href="<?php echo $general_class->ben_link('lms/quiz/index')?>" class="<?php if(in_array('my_quizzes', $general_class->toggled)): echo 'toggled'; endif; ?>">
                                            <span>My Quizzes</span>
                                        </a>
                                        
                                    </li>
                                </ul>
                            </li>

                            <li class="<?php if(in_array('my_schedule', $general_class->toggled)): echo 'active'; endif; ?>">
                                <a href="<?php echo $general_class->ben_link('general/schedule/index'); ?>">
                                    <i class="material-icons" style="margin-left:-215px">calendar_today</i>
                                    <span>My Schedule</span>
                                </a>
                                
                            </li>

                    <?php endif; ?>
                    
                    
                    
                    
                </ul>
            </div>
            <!-- #Menu -->
            
        </aside>
        <!-- #END# Left Sidebar -->
    </section>
<script type="text/javascript">

    $(document).ready(function(){
        // $('.leftsidebar').slimScroll({
        //     height:'1000px',
        //     size: '20px',
        // });
        $('.list').slimScroll({
            height:'auto',
            size: '20px',
            railVisible: true,
            alwaysVisible: true,
        });
    });
    
</script>